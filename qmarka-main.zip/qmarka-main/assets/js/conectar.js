async function productsList() {
  const promise = await fetch("https://formulario-do-luan.vercel.app/");
  const promiseConverted = await promise.json();

  return promiseConverted;
}

async function searchList(searchFieldValue) {
  const searchedProducts = await fetch(
    `https://formulario-do-luan.vercel.app/`
  );

  const convertedSearchedList = await searchedProducts.json();

  return convertedSearchedList;
}

export const conectApi = {
  productsList,
  searchList,
};
